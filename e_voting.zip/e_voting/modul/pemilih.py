from modul.utils import baca_json, simpan_json

FILE_PEMILIH = "data/pemilih.json"

def tambah_pemilih():
    data_pemilih = baca_json(FILE_PEMILIH)

    print("\n===== TAMBAH DATA PEMILIH =====")

    id_pemilih = input("Masukkan ID Pemilih : ")
    nama = input("Masukkan Nama : ")
    jurusan = input("Masukkan Jurusan : ")

    # Cek apakah ID sudah ada
    for pemilih in data_pemilih:
        if pemilih["id"] == id_pemilih:
            print("ID pemilih sudah digunakan!")
            return

    # Tambahkan data baru
    pemilih_baru = {
        "id": id_pemilih,
        "nama": nama,
        "jurusan": jurusan,
        "sudah_memilih": False
    }

    data_pemilih.append(pemilih_baru)

    # Simpan ke file JSON
    simpan_json(FILE_PEMILIH, data_pemilih)

    print("Data pemilih berhasil ditambahkan.")