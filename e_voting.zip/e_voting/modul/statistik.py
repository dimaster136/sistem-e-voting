from modul.utils import baca_json

FILE_PEMILIH = "data/pemilih.json"
FILE_CALON = "data/calon.json"

def tampilkan_statistik():
    data_pemilih = baca_json(FILE_PEMILIH)
    data_calon = baca_json(FILE_CALON)

    total_pemilih = len(data_pemilih)
    sudah_memilih = 0

    # Menghitung jumlah pemilih yang sudah memilih
    for pemilih in data_pemilih:
        if pemilih["sudah_memilih"]:
            sudah_memilih += 1

    # Menghitung persentase partisipasi
    if total_pemilih > 0:
        persentase = (sudah_memilih / total_pemilih) * 100
    else:
        persentase = 0

    # Mencari calon dengan suara terbanyak
    if len(data_calon) > 0:
        pemenang = data_calon[0]

        for calon in data_calon:
            if calon["jumlah_suara"] > pemenang["jumlah_suara"]:
                pemenang = calon

        nama_pemenang = pemenang["nama"]
        suara_terbanyak = pemenang["jumlah_suara"]
    else:
        nama_pemenang = "-"
        suara_terbanyak = 0

    print("\n===== STATISTIK PEMILU =====")
    print(f"Total Pemilih          : {total_pemilih}")
    print(f"Sudah Memilih          : {sudah_memilih}")
    print(f"Persentase Partisipasi : {persentase:.2f}%")
    print(f"Suara Terbanyak        : {nama_pemenang} ({suara_terbanyak} suara)")