import json
import os

def baca_json(nama_file):
    # Jika file belum ada, kembalikan list kosong
    if not os.path.exists(nama_file):
        return []

    try:
        with open(nama_file, "r") as file:
            return json.load(file)
    except:
        return []

def simpan_json(nama_file, data):
    with open(nama_file, "w") as file:
        json.dump(data, file, indent=4)